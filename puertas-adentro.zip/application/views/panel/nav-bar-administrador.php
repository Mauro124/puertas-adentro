<!--   ADMINISTRADOR     -->

<link rel="stylesheet" href="./assets/css/nav-bar-administrador.css">
<link rel="stylesheet" href="./assets/css/administrador.css">
<link rel="stylesheet" href="./assets/css/footer-administrador.css">


<nav id="myNav" class="navbar navbar-default" role="navigation">
    <div class="container-fluid">
        <div class="navbar-header">
            <a class="navbar-brand" href="https://www.zonajobs.com.ar/">
                <img class="img-banner" alt="Zona Jobs" src="./assets/css/img/logos/banner-zona-jobs.png">
            </a>
        </div>
        <ul class="nav navbar-nav">
            <li class="txt-panel-administrador"> Panel de Administrador</li>
        </ul>
    </div>
</nav>
