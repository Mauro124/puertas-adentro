<nav id="myNav" class="navbar navbar-default">
    <div class="container-fluid">
        <div class="navbar-header">
            <a class="navbar-brand" href="https://www.zonajobs.com.ar/">
                <img class="img-banner" src="./assets/css/img/logos/banner-zona-jobs.png" alt="zona-jobs">
            </a>
        </div>
    </div>
</nav>
