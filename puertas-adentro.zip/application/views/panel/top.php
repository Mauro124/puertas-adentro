</head>
<body>
   <div class="carga-imagenes">
        <img src="./assets/css/img/icono-facebook.png">
        <img src="./assets/css/img/icono-google.png">
        <img src="./assets/css/img/icono-linkedin.png">
        <img src="./assets/css/img/icono-twitter.png">
        <img src="./assets/css/img/icono-youtube.png">
        <img src="./assets/css/img/img-portada.png">
        <img src="./assets/css/img/zonajobs.png">
        <img src="./assets/css/img/zonajobs.png">
    </div>
    <div class="pre-load">
        <img src="./assets/css/img/oval.svg" alt="loading svg">
    </div>