<script type="text/javascript" src="./assets/js/main.js"></script>

<div id="fb-root"></div>
<!--
<script>(function(d, s, id) {
var js, fjs = d.getElementsByTagName(s)[0];
if (d.getElementById(id)) return;
js = d.createElement(s); js.id = id;
js.src = "//connect.facebook.net/es_LA/sdk.js#xfbml=1&version=v2.7&appId=1032752026781847";
fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
-->

<section class="container-fluid portada">
    <iframe name="3drt-my360View" allowfullscreen="true" marginheight="0" marginwidth="0" scrolling="no" src="http://www.imagica360sitio.com/demos/zojo/navent.html"></iframe>
    <div class="img-zona-jobs">
        <img src="./assets/css/img/zona-jobs-portada.png">
        <p>Conocé las empresas puertas adentro</p>
    </div>
</section>
<section class="container-fluid main">
    <div class="row">
        <h2>Conocé las empresas puertas adentro</h2>
        <div class="col-sm-9 col-md-9">
            <p>Hacé clic en el logo de la empresa que queres conocer puertas adentro.<br>
                Te damos la posibilidad de conocer las empresas íntimamente, ver sus espacios de trabajos, sus equipos…. </p>
            <div class="row empresas-destacadas" id="empresas-destacadas">
            </div>
            <div id="empresas-colapsadas-destacadas" class="row empresas-colapsadas-destacadas">
            </div>
            <div class="collapse" id="empresas-colapsadas">
                <div class="row empresas-secundarias" id="empresas-secundarias">
                </div>
            </div>
            <div class="row">
                <button class="btn btn-link btn-ver-mas" id="btn-ver-mas" data-toggle="collapse" data-target="#empresas-colapsadas">Ver más <span class="glyphicon glyphicon-menu-down"></span></button>

                <script>
                    $(document).ready(function(){
                        $("#empresas-colapsadas").on("hide.bs.collapse", function(){
                            $("#btn-ver-mas").html('Ver más<span class="glyphicon glyphicon-menu-down"></span>');
                        });
                        $("#empresas-colapsadas").on("show.bs.collapse", function(){
                            $("#btn-ver-mas").html('Ver menos<span class="glyphicon glyphicon-menu-up"></span> ');
                        });
                    });
                </script>
            </div>
        </div>
        <div class="col-sm-3 col-md-3 panel-social">
            <div class="row">
                <div class="panel">
                    <div class="panel-heading-facebook">
                        <h3><i class="fa fa-facebook icon-r-s"></i>
                            <a href="https://www.facebook.com/plugins/post/oembed.json/?url=https://es-es.facebook.com/zonajobscom" class="text-titulos-home-w" target="_blank" title="Ir a la pagina de Facebook de ZonaJobs">
                                ZonaJobs
                            </a>
                        </h3>

                    </div>
                    <div class="panel-cuerpo">
                        <!--
<div class="fb-page" data-href="https://www.facebook.com/zonajobscom/" data-tabs="timeline" data-height="250" data-small-header="true" data-adapt-container-width="true" data-hide-cover="true" data-show-facepile="false"><blockquote cite="https://www.facebook.com/zonajobscom/" class="fb-xfbml-parse-ignore"><a href="https://www.facebook.com/zonajobscom/">ZonaJobs</a></blockquote></div>
<br>
-->
                        <p class="txt-panel">Sumate al equipo de #Apex! Conocé todas sus ofertas laborarles y postulate ingresando al link http://goo.gl/5C7ejl #empleos #ZonaJobs </p>
                        <p class="pie-panel">Publicado ayer a las 12:01</p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="panel">
                    <div class="panel-heading-twitter">
                        <h3><i class="fa fa-twitter icon-r-s-t"></i>
                            <a href="https://twitter.com/ZonaJobs" class="text-titulos-home-w" target="_blank" title="Ir a la pagina de Twitter de ZonaJobs">
                                @ZonaJobs
                            </a>
                        </h3>
                    </div>
                    <div class="panel-cuerpo">
                        <p class="txt-panel">Los rechazos siempre son grandes aprendizajes #FraseJobs #Lunes #MondayMotivation #motiva-tion #QuotesOfTheDay #quotes http://t.co/L-bA05b6dDp  </p>
                        <p class="pie-panel">Publicado ayer a las 12:01</p>
<!--
                        <div class="socialButton">
                            <a class="twitter-timeline" data-height="250" href="https://twitter.com/ZonaJobs">Tweets by ZonaJobs</a> <script async src="//platform.twitter.com/widgets.js" charset="utf-8"></script>
                        </div>
-->
                    </div>
                </div>
            </div>
        </div>

    </div>
    </div>
</section>
<section class="row videos" style="display:none">
    <div class="banner" id="banner">
        <img src="">
    </div>
    <p>
        <iframe class="video-360" name="3drt-my360View" allowfullscreen="true" marginheight="0" marginwidth="0" scrolling="no" src="http://www.imagica360sitio.com/demos/zojo/mondelez.html"></iframe>
        <iframe class="video-youtube" src="https://www.youtube.com/embed/wiqxN1hbuzY" frameborder="0" allowfullscreen></iframe>
    </p>
</section>


<!-- Modal Error (no se completaron todos los campos)-->
<div id="myModalError" class="modal fade" role="dialog">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">×</button>
                <h4 class="modal-title">Error</h4>
            </div>
            <div class="modal-body">
                <p>Debes completar el campo</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal" data-toggle="modal" data-target="#myModalAgregarLogo">Aceptar</button>
            </div>
        </div>
    </div>
</div>