<footer class="footer-administrador">
    <div class="row">
        <button class="btn btn-primary btn-footer-administrador" id="btn-guardar"><span class="glyphicon glyphicon-floppy-disk"></span> Guardar Cambios</button>
        <a href="puertas-adentro/main"><button class="btn btn-primary btn-footer-administrador"><span class="glyphicon glyphicon-globe"></span> Ir a Puertas Adentro</button></a>
    </div>
</footer>
</body>
</html>