<footer class="footer">
    <div class="row">
        <div class="ctnr-terminos col-sm-6 col-md-6 col-xs-12">
            <p>Copyright © 2016 - Todos los derechos reservados<br><span><a href="https://www.zonajobs.com.ar/candidatos/terminos">Términos y Condiciones</a> | Protección de datos</span></p> 
        </div>
        <div class="ctnr-social col-sm-6 col-md-6 col-xs-12">
            <a href="https://www.facebook.com/zonajobscom"><img alt="facebook" src="./assets/css/img/icono-facebook.png" class="icon-facebook"></a>
            <a href="https://plus.google.com/u/0/+ZonaJobs/posts"><img alt="google" src="./assets/css/img/icono-google.png" class="icon-google"></a>
            <a href="https://www.youtube.com/user/ZonaJobsEmpleos"><img alt="youtube" src="./assets/css/img/icono-youtube.png" class="icon-youtube"></a>
            <a href="https://twitter.com/zonajobs"><img alt="twitter" src="./assets/css/img/icono-twitter.png" class="icon-twitter"></a>
            <a href="https://www.linkedin.com/start/join?trk=login_reg_redirect&session_redirect=https%3A%2F%2Fwww.linkedin.com%2Fvsearch%2Fg%3Fkeywords%3Dzonajobs%26orig%3DGLHD"><img src="./assets/css/img/icono-linkedin.png" alt="linkedin" class="icon-linkedin"></a>
        </div>
    </div>
</footer>
</body>
</html>